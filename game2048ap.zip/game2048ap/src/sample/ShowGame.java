package sample;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ShowGame extends Application {
    private Game game;

    public ShowGame(Game game) {
        this.game = game;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        play(primaryStage);
    }

    private void play(Stage primaryStage) {
        primaryStage.setTitle("2048 GAME");
        Group root = new Group();
        menuBar(primaryStage, root);
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setHeight(650);
        primaryStage.setMinWidth(570);
        primaryStage.setMaxWidth(570);
        primaryStage.setMinHeight(650);
        primaryStage.setMaxHeight(650);
        scene.setFill(Color.HOTPINK);
        show(root, primaryStage);
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.DOWN || e.getCode() == KeyCode.UP ||
                    e.getCode() == KeyCode.RIGHT || e.getCode() == KeyCode.LEFT) {
                switch (e.getCode()) {
                    case DOWN:
                        game.plying(0);
                        break;
                    case UP:
                        game.plying(1);
                        break;
                    case RIGHT:
                        game.plying(2);
                        break;
                    case LEFT:
                        game.plying(3);
                        break;
                }
                game.setFullCells();
                if (game.endGame()) {
                    if (game.getPlayer().getScore() > game.getPlayer().getHighScore())
                        game.getPlayer().setHighScore(game.getPlayer().getScore());
                    game.getPlayer().setScore(0);
                    game.endGame = true;
                    gameOver(primaryStage);
                    return;
                }
                if (game.getFullCells() != game.getNumberOfRowsAndColumns() * game.getNumberOfRowsAndColumns())
                    game.fullRandomCell();

                show(root, primaryStage);
                if (game.endGame) {
                    StackPane stackPane = new StackPane(root);
                    scene.setRoot(stackPane);
                    stackPane.setAlignment(Pos.CENTER);
                    Label label = new Label("game over!");

                    label.setText("GAME OVER\nScore: " + game.getPlayer().getScore());
                    label.relocate(250, 250);
                    label.setFont(Font.font(27));
                    label.setTextFill(Color.DEEPPINK);
                    stackPane.getChildren().add(label);
                    primaryStage.show();

                    primaryStage.close();
                }
            }
        });

        primaryStage.show();
    }

    private void show(Group root, Stage primaryStage) {
        primaryStage.setTitle("2048 GAME");

        int distanceH = 570 / game.getNumberOfRowsAndColumns();
        int distanceW = 600 / game.getNumberOfRowsAndColumns();
        int distance = 45;
        for (int i = 0; i < game.getNumberOfRowsAndColumns(); i++) {
            for (int j = 0; j < game.getNumberOfRowsAndColumns(); j++) {

                Label label = new Label(Integer.toString(game.cells[i][j]));

                label.setText(Integer.toString(game.cells[i][j]));
                label.relocate(j * distanceW + distanceW * 2 / 6, distance + i * distanceH + distanceH * 2 / 6);
                label.setFont(Font.font(27));
                label.setTextFill(Color.WHITE);
                if (game.cells[i][j] == 2 || game.cells[i][j] == 4)
                    label.setTextFill(Color.BLACK);

                Rectangle rectangle = new Rectangle(j * distanceH, distance + i * distanceH, distanceH, distance + distanceW);

                switch (game.cells[i][j]) {
                    case 0:
                        rectangle.setFill(Color.BLANCHEDALMOND);
                        break;
                    case 2:
                        rectangle.setFill(Color.LIGHTPINK);
                        break;
                    case 4:
                        rectangle.setFill(Color.rgb(250, 211, 133));
                        break;
                    case 8:
                        rectangle.setFill(Color.rgb(255, 166, 77));
                        break;
                    case 16:
                        rectangle.setFill(Color.rgb(255, 148, 77));
                        break;
                    case 32:
                        rectangle.setFill(Color.rgb(83, 237, 198));
                        break;
                    case 64:
                        rectangle.setFill(Color.rgb(255, 51, 51));
                        break;
                    case 128:
                        rectangle.setFill(Color.rgb(243, 219, 114));
                        break;
                    case 256:
                        rectangle.setFill(Color.rgb(242, 200, 13));
                        break;
                    case 512:
                        rectangle.setFill(Color.rgb(179, 255, 102));
                        break;
                    case 1024:
                        rectangle.setFill(Color.rgb(0, 0, 0));
                        break;
                    case 2048:
                        rectangle.setFill(Color.rgb(255, 117, 26));
                        win(primaryStage);
                        return;
                }
                Line line1 = new Line(j * distanceH, distance, j * distanceH, 650);
                Line line2 = new Line(0, distance + i * distanceH, 570, distance + i * distanceH);
                line1.setFill(Color.rgb(228, 233, 199));
                line2.setFill(Color.rgb(228, 233, 199));
                root.getChildren().addAll(rectangle, line1, line2);
                if (game.cells[i][j] != 0)
                    root.getChildren().add(label);

                Rectangle r = new Rectangle(400, 0, 150, distance - 5);
                r.setFill(Color.HOTPINK);
                Label scoreboard = new Label();
                scoreboard.setText("Score  " + game.getPlayer().getScore());
                scoreboard.setTextFill(Color.DEEPSKYBLUE);
                scoreboard.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD, 20));
                scoreboard.relocate(400, 0);
                scoreboard.setVisible(true);
                scoreboard.setPrefHeight(distance);
                scoreboard.setPrefWidth(150);
                root.getChildren().add(r);
                root.getChildren().add(scoreboard);
            }
        }
    }

    private void win(Stage stage) {
        stage.setTitle("2048 GAME");
        StackPane root = new StackPane();
        Scene scene = new Scene(root, 400, 400);
        Rectangle rectangle = new Rectangle(0, 0, 1000, 1000);
        root.getChildren().add(rectangle);
        Image image = null;
        try {
            image = new Image(new FileInputStream("1.png"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        ImageView imageView = new ImageView(image);
        imageView.relocate(0, 0);
        imageView.setFitHeight(450);
        imageView.setFitWidth(450);
        root.getChildren().add(imageView);
        stage.setScene(scene);
        stage.show();
    }

    private void menuBar(Stage primaryStage, Group root) {
        primaryStage.setTitle("2048 GAME");
        Menu m = new Menu("Menu");
        MenuItem m1 = new MenuItem("New Game");
        MenuItem m2 = new MenuItem("End Game and Show Ranking");
        MenuItem m3 = new MenuItem("End Game");
        m.getItems().addAll(m1, m2, m3);
        MenuBar mb = new MenuBar();
        mb.getMenus().add(m);
        root.getChildren().add(mb);

        m1.setOnAction(event -> {
            if (game.getPlayer().getScore() > game.getPlayer().getHighScore())
                game.getPlayer().setHighScore(game.getPlayer().getScore());
            game.getPlayer().setScore(0);
            Game newGame = new Game(game.getPlayer(), game.getNumberOfRowsAndColumns());
            ShowGame showGame = new ShowGame(newGame);
            showGame.play(primaryStage);
        });

        m2.setOnAction(event -> {
            if (game.getPlayer().getScore() > game.getPlayer().getHighScore())
                game.getPlayer().setHighScore(game.getPlayer().getScore());
            game.getPlayer().setScore(0);
            ShowMainMenu.ranking(primaryStage);
        });

        m3.setOnAction(event -> {
            if (game.getPlayer().getScore() > game.getPlayer().getHighScore())
                game.getPlayer().setHighScore(game.getPlayer().getScore());
            game.getPlayer().setScore(0);
            primaryStage.close();
        });
    }

    private static void gameOver(Stage stage) {
        StackPane root = new StackPane();
        Scene scene = new Scene(root, 400, 400);
        Rectangle rectangle = new Rectangle(0, 0, 1000, 1000);
        root.getChildren().add(rectangle);
        Image image = null;
        try {
            image = new Image(new FileInputStream("2.jpg"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        ImageView imageView = new ImageView(image);
        imageView.relocate(0, 0);
        imageView.setFitHeight(450);
        imageView.setFitWidth(450);
        root.getChildren().add(imageView);
        stage.setScene(scene);

        stage.show();
    }

}
