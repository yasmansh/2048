package sample;

import java.util.Random;

public class Game {

    private int numberOfRowsAndColumns;
    public int[][] cells = new int[20][20];
    private Account player;
    private int fullCells = 0;
    boolean endGame = false;

    public Game(Account player, int numberOfRowsAndColumns) {
        setPlayer(player);
        setNumberOfRowsAndColumns(numberOfRowsAndColumns);
        setCellsInFirst();
    }

    public Account getPlayer() {
        return player;
    }

    private void setCellsInFirst() {
        boolean[][] complete = new boolean[numberOfRowsAndColumns][numberOfRowsAndColumns];
        Random random = new Random();
        int number = random.nextInt(numberOfRowsAndColumns * 2 / 3) + 2;
        for (int i = 0; i < number; i++) {
            int row = random.nextInt(numberOfRowsAndColumns),
                    column = random.nextInt(numberOfRowsAndColumns);
            while (complete[row][column]) {
                row = random.nextInt(numberOfRowsAndColumns);
                column = random.nextInt(numberOfRowsAndColumns);
            }
            int r = random.nextInt(3);
            cells[row][column] = 2 + (r == 0 ? 2 : 0);
            complete[row][column] = true;
        }
    }

    public boolean endGame() {
        if (getFullCells() == (numberOfRowsAndColumns * numberOfRowsAndColumns)) {
            for (int i = 0; i < numberOfRowsAndColumns; i++) {
                for (int j = 1; j < numberOfRowsAndColumns; j++) {
                    if (cells[i][j] == cells[i][j - 1])
                        return false;
                    if (cells[j][i] == cells[j - 1][i])
                        return false;
                }
            }
            return true;
        }
        return false;
    }

    public void plying(int direction) {
        switch (direction) {
            case 0:
                down();
                break;
            case 1:
                up();
                break;
            case 2:
                right();
                break;
            case 3:
                left();
                break;
        }
    }

    public void fullRandomCell() {
        Random random = new Random();
        int row = random.nextInt(numberOfRowsAndColumns);
        int column = random.nextInt(numberOfRowsAndColumns);
        while (cells[row][column] != 0) {
            row = random.nextInt(numberOfRowsAndColumns);
            column = random.nextInt(numberOfRowsAndColumns);
        }
        cells[row][column] = (random.nextInt(3) == 0 ? 4 : 2);
    }

    private void left() {

        boolean[][] merge = new boolean[numberOfRowsAndColumns][numberOfRowsAndColumns];

        for (int r = 0; r < numberOfRowsAndColumns; r++) {
            int column = 0;
            boolean isMergeInLast = false;
            for (int c = 0; c < numberOfRowsAndColumns - 1; c++) {
                if (merge[r][c]) {
                    continue;
                }
                if (cells[r][c] != 0 && cells[r][c + 1] != 0) {
                    if (cells[r][c] == cells[r][c + 1]) {
                        cells[r][column] = cells[r][c] * 2;
                        merge[r][c] = true;
                        merge[r][c + 1] = true;
                        isMergeInLast = true;
                        player.addScore(cells[r][c] * 2);
                        column++;
                        cells[r][c + 1] = 0;
                        if (column != (c + 1)) {
                            cells[r][c] = 0;
                        }
                    } else {
                        if (!isMergeInLast && column > 0 && cells[r][column - 1] == cells[r][c] &&
                                (column - 1) != c) {
                            cells[r][column - 1] = cells[r][c] * 2;
                            player.addScore(cells[r][c] * 2);
                            isMergeInLast = true;
                            cells[r][column] = cells[r][column + 1];
                            cells[r][c] = 0;
                            cells[r][c + 1] = 0;
                            column++;
                        } else {
                            cells[r][column] = cells[r][c];
                            column++;
                            isMergeInLast = false;
                            if (column != (c + 1)) {
                                cells[r][c] = 0;
                            }
                        }
                    }
                } else if (cells[r][c] != 0) {
                    if (!isMergeInLast && column > 0 && cells[r][column - 1] == cells[r][c] && (column - 1) != c) {
                        cells[r][column - 1] = cells[r][c] * 2;
                        player.addScore(cells[r][c] * 2);
                        isMergeInLast = true;
                        cells[r][c] = 0;
                    } else {
                        cells[r][column] = cells[r][c];
                        column++;
                        isMergeInLast = false;
                        if (column != (c + 1))
                            cells[r][c] = 0;
                    }
                } else if (cells[r][c + 1] != 0) {
                    if (!isMergeInLast && column > 0 && cells[r][column - 1] == cells[r][c + 1] && (column - 1) != (c + 1)) {
                        cells[r][column - 1] = cells[r][c + 1] * 2;
                        player.addScore(cells[r][c + 1] * 2);
                        isMergeInLast = true;
                        cells[r][c + 1] = 0;
                    } else {
                        cells[r][column] = cells[r][c + 1];
                        column++;
                        isMergeInLast = false;
                        if (column != (c + 2))
                            cells[r][c + 1] = 0;
                    }
                }
            }
        }
    }

    private void up() {

        boolean[][] merge = new boolean[numberOfRowsAndColumns][numberOfRowsAndColumns];
        for (int c = 0; c < numberOfRowsAndColumns; c++) {
            int row = 0;
            boolean isMergeInLast = false;
            for (int r = 0; r < numberOfRowsAndColumns - 1; r++) {
                if (merge[r][c]) {
                    continue;
                }
                if (cells[r][c] != 0 && cells[r + 1][c] != 0) {
                    if (cells[r][c] == cells[r + 1][c]) {
                        cells[row][c] = cells[r][c] * 2;
                        merge[r][c] = true;
                        merge[r + 1][c] = true;
                        isMergeInLast = true;
                        player.addScore(cells[r][c] * 2);
                        row++;
                        cells[r + 1][c] = 0;
                        if (row != (r + 1)) {
                            cells[r][c] = 0;
                        }
                    } else {
                        if (!isMergeInLast && row > 0 && cells[row - 1][c] == cells[r][c] && (row - 1) != r) {
                            cells[row - 1][c] = cells[r][c] * 2;
                            player.addScore(cells[r][c] * 2);
                            isMergeInLast = true;
                            cells[row][c] = cells[r + 1][c];
                            cells[r][c] = 0;
                            cells[r + 1][c] = 0;
                            row++;
                        } else {
                            cells[row][c] = cells[r][c];
                            row++;
                            isMergeInLast = false;
                            if (row != (r + 1)) {
                                cells[r][c] = 0;
                            }
                        }
                    }
                } else if (cells[r][c] != 0) {
                    if (!isMergeInLast && row > 0 && cells[row - 1][c] == cells[r][c] && (row - 1) != r) {
                        cells[row - 1][c] = cells[r][c] * 2;
                        player.addScore(cells[r][c] * 2);
                        isMergeInLast = true;
                        cells[r][c] = 0;
                    } else {
                        cells[row][c] = cells[r][c];
                        row++;
                        isMergeInLast = false;
                        if (row != (r + 1))
                            cells[r][c] = 0;
                    }
                } else if (cells[r + 1][c] != 0) {
                    if (!isMergeInLast && row > 0 && cells[row - 1][c] == cells[r + 1][c] && (row - 1) != (r + 1)) {
                        cells[row - 1][c] = cells[r + 1][c] * 2;
                        player.addScore(cells[r + 1][c] * 2);
                        isMergeInLast = true;
                        cells[r + 1][c] = 0;
                    } else {
                        cells[row][c] = cells[r + 1][c];
                        row++;
                        isMergeInLast = false;
                        if (row != (r + 2))
                            cells[r + 1][c] = 0;
                    }
                }
            }
        }
    }

    private void right() {
        boolean[][] merge = new boolean[numberOfRowsAndColumns][numberOfRowsAndColumns];
        for (int r = 0; r < numberOfRowsAndColumns; r++) {
            int column = numberOfRowsAndColumns - 1;
            boolean isMergeInLast = false;
            for (int c = numberOfRowsAndColumns - 1; c > 0; c--) {
                if (merge[r][c]) {
                    continue;
                }
                if (cells[r][c] != 0 && cells[r][c - 1] != 0) {
                    if (cells[r][c] == cells[r][c - 1]) {
                        cells[r][column] = cells[r][c] * 2;
                        merge[r][c] = true;
                        merge[r][c - 1] = true;
                        isMergeInLast = true;
                        player.addScore(cells[r][c] * 2);
                        column--;
                        cells[r][c - 1] = 0;
                        if (column != (c - 1)) {
                            cells[r][c] = 0;
                        }
                    } else {
                        if (!isMergeInLast && column < (numberOfRowsAndColumns - 1) && cells[r][column + 1] == cells[r][c] &&
                                (column + 1) != c) {
                            cells[r][column + 1] = cells[r][c] * 2;
                            player.addScore(cells[r][c] * 2);
                            isMergeInLast = true;
                            cells[r][column] = cells[r][c - 1];
                            cells[r][c - 1] = 0;
                            cells[r][c] = 0;
                            column--;
                        } else {
                            cells[r][column] = cells[r][c];
                            column--;
                            isMergeInLast = false;
                            if (column != (c - 1)) {
                                cells[r][c] = 0;
                            }
                        }
                    }
                } else if (cells[r][c] != 0) {
                    if (!isMergeInLast && column < (numberOfRowsAndColumns - 1)
                            && cells[r][column + 1] == cells[r][c] && (column + 1) != c) {
                        cells[r][column + 1] = cells[r][c] * 2;
                        player.addScore(cells[r][c] * 2);
                        isMergeInLast = true;
                        cells[r][c] = 0;
                    } else {
                        cells[r][column] = cells[r][c];
                        column--;
                        isMergeInLast = false;
                        if (column != (c - 1))
                            cells[r][c] = 0;
                    }
                } else if (cells[r][c - 1] != 0) {
                    if (!isMergeInLast && column < (numberOfRowsAndColumns - 1)
                            && cells[r][column + 1] == cells[r][c - 1] && (column + 1) != (c - 1)) {
                        cells[r][column + 1] = cells[r][c - 1] * 2;
                        player.addScore(cells[r][c - 1] * 2);
                        isMergeInLast = true;
                        cells[r][c - 1] = 0;
                    } else {
                        cells[r][column] = cells[r][c - 1];
                        column--;
                        isMergeInLast = false;
                        if (column != (c - 2))
                            cells[r][c - 1] = 0;
                    }
                }
            }
        }
    }

    private void down() {
        boolean[][] merge = new boolean[numberOfRowsAndColumns][numberOfRowsAndColumns];
        for (int c = 0; c < numberOfRowsAndColumns; c++) {
            int row = numberOfRowsAndColumns - 1;
            boolean isMergeInLast = false;
            for (int r = numberOfRowsAndColumns - 1; r > 0; r--) {
                if (merge[r][c]) {
                    continue;
                }
                if (cells[r][c] != 0 && cells[r - 1][c] != 0) {
                    if (cells[r][c] == cells[r - 1][c]) {
                        cells[row][c] = cells[r][c] * 2;
                        merge[r][c] = true;
                        merge[r - 1][c] = true;
                        isMergeInLast = true;
                        player.addScore(cells[r][c] * 2);
                        row--;
                        cells[r - 1][c] = 0;
                        if (row != (r - 1)) {
                            cells[r][c] = 0;
                        }
                    } else {
                        if (!isMergeInLast && row < (numberOfRowsAndColumns - 1) && cells[row + 1][c] == cells[r][c] &&
                                (row + 1) != r) {
                            cells[row + 1][c] = cells[r][c] * 2;
                            player.addScore(cells[r][c] * 2);
                            isMergeInLast = true;
                            cells[row][c] = cells[r - 1][c];
                            cells[r - 1][c] = 0;
                            cells[r][c] = 0;
                            row--;
                        } else {
                            cells[row][c] = cells[r][c];
                            row--;
                            isMergeInLast = false;
                            if (row != (r - 1)) {
                                cells[r][c] = 0;
                            }
                        }
                    }
                } else if (cells[r][c] != 0) {
                    if (!isMergeInLast && row < (numberOfRowsAndColumns - 1)
                            && cells[row + 1][c] == cells[r][c] && (row + 1) != r) {
                        cells[row + 1][c] = cells[r][c] * 2;
                        player.addScore(cells[r][c] * 2);
                        isMergeInLast = true;
                        cells[r][c] = 0;
                    } else {
                        cells[row][c] = cells[r][c];
                        isMergeInLast = false;
                        row--;
                        if (row != (r - 1))
                            cells[r][c] = 0;
                    }
                } else if (cells[r - 1][c] != 0) {
                    if (!isMergeInLast && row < (numberOfRowsAndColumns - 1)
                            && cells[row + 1][c] == cells[r - 1][c] && (row + 1) != (r - 1)) {
                        cells[row + 1][c] = cells[r - 1][c] * 2;
                        player.addScore(cells[r - 1][c] * 2);
                        isMergeInLast = true;
                        cells[r - 1][c] = 0;
                    } else {
                        cells[row][c] = cells[r - 1][c];
                        row--;
                        isMergeInLast = false;
                        if (row != (r - 2))
                            cells[r - 1][c] = 0;
                    }
                }
            }
        }
    }

    public int getNumberOfRowsAndColumns() {
        return numberOfRowsAndColumns;
    }

    public void setNumberOfRowsAndColumns(int numberOfRowsAndColumns) {
        this.numberOfRowsAndColumns = numberOfRowsAndColumns;
    }

    public void setPlayer(Account player) {
        this.player = player;
    }

    public int getFullCells() {
        return fullCells;
    }

    public void setFullCells() {
        int count = 0;
        for (int row = 0; row < numberOfRowsAndColumns; row++) {
            for (int column = 0; column < numberOfRowsAndColumns; column++) {
                if (cells[row][column] != 0) {
                    count++;
                }
            }
        }
        this.fullCells = count;
    }

}