package sample;

import java.util.ArrayList;
import java.util.Collections;

public class Account {
    private static ArrayList<Account> accounts = new ArrayList<>();
    private String userName;
    private String password;
    private int score = 0;
    private int highScore = 0;

    public void setScore(int score) {
        this.score = score;
    }

    public Account(String userName, String password) {
        setUserName(userName);
        setPassword(password);
        accounts.add(this);
    }

    public static Account getAccount(String userName) {
        for (int i = 0; i < accounts.size(); i++) {
            if (accounts.get(i).getUserName().equals(userName))
                return accounts.get(i);
        }
        return null;
    }

    public static void sort() {
        for (int i = 0; i < accounts.size() - 1; i++)
            for (int j = 0; j < accounts.size() - 1 - i; j++)
                if (accounts.get(j).getHighScore() < accounts.get(j + 1).getHighScore())
                    Collections.swap(accounts, j, j + 1);
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public static String getPasswordByUserName(String userName) {
        for (int i = 0; i < accounts.size(); i++) {
            if (accounts.get(i).getUserName().equals(userName))
                return accounts.get(i).getPassword();
        }
        return null;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getScore() {
        return score;
    }

    public void addScore(int score) {
        this.score += score;
    }

    public static ArrayList<Account> getAccounts() {
        return accounts;
    }

    public int getHighScore() {
        return highScore;
    }

    public void setHighScore(int highScore) {
        this.highScore = highScore;
    }

}
