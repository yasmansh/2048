package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ShowMainMenu extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        signUp(primaryStage);
    }

    private static void login(Stage primaryStage) {
        primaryStage.setTitle("2048 GAME");
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(20);
        grid.setVgap(20);
        grid.setPrefSize(550, 500);
        grid.setMaxSize(550, 550);
        grid.setMinSize(200, 200);
        grid.setPadding(new Insets(25));

        menuBar(primaryStage, grid);

        Text sceneTitle = new Text("Welcome :)");
        sceneTitle.setFont(Font.font("Tahoma", FontWeight.BOLD, 22));
        sceneTitle.setFill(Color.HOTPINK);
        grid.add(sceneTitle, 0, 0, 2, 1);

        Label userName = new Label("Username: ");
        grid.add(userName, 0, 1);

        TextField userTextField = new TextField();
        grid.add(userTextField, 1, 1);

        Label pw = new Label("Password:");
        grid.add(pw, 0, 2);

        PasswordField passwordFieldw = new PasswordField();
        grid.add(passwordFieldw, 1, 2);

        Label number = new Label("Enter number of rows & columns:");
        grid.add(number, 0, 3);

        TextField numberTextField = new TextField();
        grid.add(numberTextField, 1, 3);

        Button btn = new Button("Login");

        HBox hbBtn = new HBox(10);
        hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn.getChildren().add(btn);
        grid.add(hbBtn, 1, 4);

        final Text actiontarget = new Text();
        grid.add(actiontarget, 1, 6);

        btn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                actiontarget.setFill(Color.FIREBRICK);
                String text = "";
                try {
                    if (Account.getPasswordByUserName(userTextField.getText()) == null) {
                        text = "invalid userName";
                    } else if (!Account.getPasswordByUserName(userTextField.getText()).equals(passwordFieldw.getText())) {
                        text = "invalid password";
                    } else {
                        text = "welcome!";
                        Account account = Account.getAccount(userTextField.getText());
                        Game game = new Game(account, Integer.parseInt(numberTextField.getText()));
                        ShowGame showGame = new ShowGame(game);
                        showGame.start(primaryStage);
                    }
                } catch (Exception name) {
                    text = "please enter number!";
                }
                actiontarget.setText(text);
            }
        });

        Scene scene = new Scene(grid, 600, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private static void signUp(Stage primaryStage) {
        primaryStage.setTitle("2048 GAME");
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(15);
        grid.setVgap(15);
        grid.setPrefSize(720, 500);
        grid.setMinSize(200, 200);
        grid.setPadding(new Insets(25));

        menuBar(primaryStage, grid);

        Text sceneTitle = new Text("Sign Up");
        sceneTitle.setFont(Font.font("Tahoma", FontWeight.BOLD, 22));
        sceneTitle.setFill(Color.HOTPINK);
        grid.add(sceneTitle, 0, 0, 2, 1);

        Label userName = new Label("Please Enter UserName: ");
        grid.add(userName, 0, 1);

        TextField userTextField = new TextField();
        userTextField.setAlignment(Pos.CENTER_LEFT);
        grid.add(userTextField, 1, 1);

        Label pw1 = new Label("Password:");
        grid.add(pw1, 0, 2);

        PasswordField passwordFieldw1 = new PasswordField();
        grid.add(passwordFieldw1, 1, 2);

        Label pw2 = new Label("Repeat Password:");
        grid.add(pw2, 0, 3);

        PasswordField passwordFieldw2 = new PasswordField();
        grid.add(passwordFieldw2, 1, 3);

        Button btn = new Button("Sign Up");
        btn.setFont(Font.font("Arial Narrow"));
        btn.setAlignment(Pos.CENTER);

        HBox hbBtn = new HBox(10);
        hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn.getChildren().add(btn);
        grid.add(hbBtn, 1, 4);

        final Text actiontarget = new Text();
        grid.add(actiontarget, 1, 6);

        btn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                actiontarget.setFill(Color.FIREBRICK);
                String text = "";
                try {
                    if (Account.getPasswordByUserName(userTextField.getText()) != null) {
                        text = "This username isn't available. Please try again.";
                    } else {
                        if (!passwordFieldw1.getText().equals(passwordFieldw2.getText())) {
                            text = "The passwords do not match! ";
                        } else {
                            text = "welcome " + userTextField.getText() + " :)";
                            Account account = new Account(userTextField.getText(), passwordFieldw1.getText());
                        }
                    }
                } catch (Exception name) {
                }
                actiontarget.setText(text);
            }
        });

        Scene scene = new Scene(grid, 500, 250);
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void ranking(Stage primaryStage) {
        primaryStage.setTitle("2048 GAME");
        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(20);
        root.setVgap(20);
        root.setPrefSize(500, 600);
        root.setPadding(new Insets(25));

        Text sceneTitle = new Text("Ranking");
        sceneTitle.setFont(Font.font("Tahoma", FontWeight.BOLD, 22));
        sceneTitle.setFill(Color.HOTPINK);
        root.add(sceneTitle, 0, 0);

        menuBar(primaryStage, root);

        Account.sort();
        for (int i = 0; i < Account.getAccounts().size(); i++) {
            Label label1 = new Label();
            label1.setText("Name: " + Account.getAccounts().get(i).getUserName() + "   High Score:" +
                    Account.getAccounts().get(i).getHighScore());
            label1.setFont(Font.font("Verdana", 18));
            label1.setTextFill(Color.DEEPPINK);
            root.add(label1, 0, i + 1);
        }

        Scene scene = new Scene(root, 500, 500, Color.BLACK);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private static void menuBar(Stage primaryStage, GridPane root) {
        primaryStage.setTitle("2048 GAME");
        Menu m = new Menu("Menu");
        MenuItem m1 = new MenuItem("Login");
        MenuItem m2 = new MenuItem("Sign Up");
        MenuItem m3 = new MenuItem("Ranking");
        MenuItem m4 = new MenuItem("Quit");

        m.getItems().addAll(m1, m2, m3, m4);
        MenuBar mb = new MenuBar();
        mb.getMenus().add(m);
        root.add(mb, 2, 0);


        m1.setOnAction(event -> {
            login(primaryStage);
        });

        m2.setOnAction(event -> {
            signUp(primaryStage);
        });

        m3.setOnAction(event -> {
            ranking(primaryStage);
        });

        m4.setOnAction(event -> {
            primaryStage.close();
        });
    }

}
